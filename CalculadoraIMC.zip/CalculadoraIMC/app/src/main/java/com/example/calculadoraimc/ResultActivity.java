package com.example.calculadoraimc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import java.text.DecimalFormat;

public class ResultActivity extends AppCompatActivity {
    TextView resultado;
    String strNome, imcF;
    float fltAltura, fltPeso, fltResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        DecimalFormat df = new DecimalFormat("0.00");

        resultado = (TextView) findViewById(R.id.textViewResult);
        Intent intent = getIntent();
        strNome =intent.getStringExtra("nome");
        fltAltura = Float.parseFloat(intent.getStringExtra("altura"));
        fltPeso = Float.parseFloat(intent.getStringExtra("peso"));

        fltResult = fltPeso/(fltAltura*fltAltura);


        imcF = df.format(fltResult)+"";

        resultado.setText("Ola "+strNome+" Seu imc é "+imcF);
    }
}