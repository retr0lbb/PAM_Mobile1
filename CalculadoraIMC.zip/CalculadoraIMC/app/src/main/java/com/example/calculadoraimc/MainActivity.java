package com.example.calculadoraimc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

   EditText peso,nome,altura;
   Button calButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome = (EditText) findViewById(R.id.editNome);
        peso = (EditText) findViewById(R.id.editPeso);
        altura = (EditText) findViewById(R.id.editAltura);
        calButton = (Button) findViewById(R.id.CalcButton);

        calButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarResultado();
            }
        });
    }

    public void mostrarResultado(){
        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("nome", nome.getText().toString());
        intent.putExtra("altura", altura.getText().toString());
        intent.putExtra("peso", peso.getText().toString());
        startActivity(intent);
    }

}